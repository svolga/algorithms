package algorithm.sprint1.hand;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

// ID посылки: 95477575
// Посылка: https://contest.yandex.ru/contest/22450/submits/
// B. Ловкость рук
// https://contest.yandex.ru/contest/22450/problems/B/

public class Main {

    private final int colCount = 4;
    private final int rowCount = 4;
    private final int personCount = 2;

    public static void main(String[] args) throws IOException {
        new Main().run();
    }

    private void run() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int k = personCount * Integer.parseInt(reader.readLine());

        Map<Integer, Integer> map = getMapData(reader);

        long count = map.entrySet()
                .stream()
                .filter(entry -> entry.getValue() <= k)
                .count();

        System.out.println(count);
    }

    private Map<Integer, Integer> getMapData(BufferedReader reader) throws IOException {
        Map<Integer, Integer> map = new HashMap<>();

        for (int i = 0; i < rowCount; i++) {
            String row = reader.readLine();
            for (int j = 0; j < colCount; j++) {
                int value = charToInt(row.charAt(j));
                if (value > 0) {
                    map.put(value, map.getOrDefault(value, 0) + 1);
                }
            }
        }
        return map;
    }

    private int charToInt(char t) {
        try {
            return Integer.valueOf(Character.toString(t));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

}
